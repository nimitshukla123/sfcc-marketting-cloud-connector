
package webreferences2.etframework;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TriggeredSendClassEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TriggeredSendClassEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Standard"/>
 *     &lt;enumeration value="SMTPRestV1"/>
 *     &lt;enumeration value="SMTPRestV2"/>
 *     &lt;enumeration value="SMTPRestV3"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TriggeredSendClassEnum")
@XmlEnum
public enum TriggeredSendClassEnum {

    @XmlEnumValue("Standard")
    STANDARD("Standard"),
    @XmlEnumValue("SMTPRestV1")
    SMTP_REST_V_1("SMTPRestV1"),
    @XmlEnumValue("SMTPRestV2")
    SMTP_REST_V_2("SMTPRestV2"),
    @XmlEnumValue("SMTPRestV3")
    SMTP_REST_V_3("SMTPRestV3");
    private final String value;

    TriggeredSendClassEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TriggeredSendClassEnum fromValue(String v) {
        for (TriggeredSendClassEnum c: TriggeredSendClassEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
