
package webreferences2.etframework;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DataExtensionFieldStorageType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DataExtensionFieldStorageType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Unspecified"/>
 *     &lt;enumeration value="Plain"/>
 *     &lt;enumeration value="Obfuscated"/>
 *     &lt;enumeration value="Encrypted"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DataExtensionFieldStorageType")
@XmlEnum
public enum DataExtensionFieldStorageType {

    @XmlEnumValue("Unspecified")
    UNSPECIFIED("Unspecified"),
    @XmlEnumValue("Plain")
    PLAIN("Plain"),
    @XmlEnumValue("Obfuscated")
    OBFUSCATED("Obfuscated"),
    @XmlEnumValue("Encrypted")
    ENCRYPTED("Encrypted");
    private final String value;

    DataExtensionFieldStorageType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DataExtensionFieldStorageType fromValue(String v) {
        for (DataExtensionFieldStorageType c: DataExtensionFieldStorageType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
